import uuid
from promptly.clients import api_client

task_id = None

def test_create_task():
    global task_id
    url = "https://example.com"
    goal = "Find the homepage title"
    result = api_client.create_task(url, goal)
    print(result)
    task_id = result.get("task_id")
    assert isinstance(result, dict)
    assert "task_id" in result or "error" in result

def test_run_task():
    global task_id
    result = api_client.run_task(task_id)
    print(result)
    assert isinstance(result, dict)
    assert "error" in result or "result" in result

def test_get_task_status():
    global task_id
    result = api_client.get_task_status(task_id)
    print(result)
    assert isinstance(result, dict)
    assert "error" in result or "status" in result

def test_update_task():
    global task_id
    result = api_client.update_task(task_id, url="https://example.com/updated")
    print(result)
    assert isinstance(result, dict)
    assert result.get("url") == "https://example.com/updated"
    assert "error" in result or "message" in result

def test_delete_task():
    global task_id
    result = api_client.delete_task(task_id)
    print(result)
    assert isinstance(result, dict)
    assert "error" in result or "message" in result
